import re
from lxml import etree
import copy
import logging
import html

# Setup logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

def sanitize_xml(file_path):
    """
    Sanitize the XML file by removing any invalid XML characters.
    Invalid characters in the range of [\x00-\x1F] (control characters) are removed, except for \t, \n, and \r.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # First remove any invalid numeric character references (e.g., &#31; or &#x1F;)
        content = re.sub(r'&#(?:x[0-9A-Fa-f]+|[0-9]+);', '', content)

        # Now remove invalid control characters (anything in the range \x00-\x1F except \t, \n, \r)
        sanitized_content = re.sub(r'[^\x09\x0A\x0D\x20-\xFF]', '', content)

        # Save sanitized content back to the file or return the sanitized string
        sanitized_file_path = file_path.replace('.jmx', '_sanitized.jmx')
        with open(sanitized_file_path, 'w', encoding='utf-8') as f:
            f.write(sanitized_content)

        logging.info(f"Sanitized XML saved to {sanitized_file_path}")
        return sanitized_file_path
    except Exception as e:
        logging.error(f"Error sanitizing XML: {e}")
        raise

def parse_jmx(file_path):
    try:
        tree = etree.parse(file_path)
        root = tree.getroot()
        return tree, root
    except Exception as e:
        logging.error(f"Error parsing JMX file {file_path}: {e}")
        raise

def find_http_samplers(root):
    return root.xpath(".//HTTPSamplerProxy")

def find_elements_in_request_subtree(request):
    return request.xpath("./following-sibling::hashTree/*")

def find_request_by_name(root, request_name):
    all_requests = root.xpath(".//HTTPSamplerProxy/@testname")
    logging.debug(f"Request names in new script: {all_requests}")
    return root.xpath(f".//HTTPSamplerProxy[@testname='{request_name}']")

def parse_jtl(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return content
    except Exception as e:
        logging.error(f"Error reading JTL file {file_path}: {e}")
        raise

def find_request_in_jtl(jtl_content, request_name):
    request_pattern = re.compile(f'<httpSample.*?lb="{request_name}".*?>(.*?)</httpSample>', re.DOTALL)
    matches = request_pattern.findall(jtl_content)
    return matches

def find_dynamic_values_in_jtl(jtl_response, regex):
    jtl_response = html.unescape(jtl_response)
    matches = re.finditer(regex, jtl_response)
    dynamic_values = []
    for match in matches:
        dynamic_value = [match.group(i) for i in range(1, len(match.groups()) + 1)]
        dynamic_values.append(dynamic_value)
    return dynamic_values

def replace_dynamic_values_in_jmx(request, dynamic_values, regex_variable_name):
    request_content = etree.tostring(request).decode("utf-8")
    logging.debug(f"Original request content: {request_content}")

    replacement_success = True

    for dynamic_value_set in dynamic_values:
        for i, value in enumerate(dynamic_value_set):
            placeholder = f"${{{regex_variable_name}_{i+1}}}"
            escaped_value = re.escape(value)
            logging.debug(f"Replacing dynamic value '{value}' with placeholder '{placeholder}'")
            new_content = re.sub(escaped_value, placeholder, request_content)
            if new_content == request_content:
                replacement_success = False
                logging.debug(f"Replacement failed for dynamic value '{value}'")
            request_content = new_content

    logging.debug(f"Modified request content: {request_content}")

    if replacement_success:
        logging.debug(f"Replacement succeeded")
    else:
        logging.debug(f"Replacement failed for some placeholders")

    request = etree.fromstring(request_content.encode("utf-8"))
    return request

def validate_and_apply_extractor(element, jtl_content):
    try:
        regex = element.find(".//stringProp[@name='RegexExtractor.regex']").text
        refname = element.find(".//stringProp[@name='RegexExtractor.refname']").text
        template = element.find(".//stringProp[@name='RegexExtractor.template']").text
        match_number = element.find(".//stringProp[@name='RegexExtractor.match_number']").text

        if not regex or not refname or not template or not match_number:
            logging.error("Missing one or more required fields in RegexExtractor")
            return False

        logging.info(f"Validating RegexExtractor: regex={regex}, refname={refname}, template={template}, match_number={match_number}")

        jtl_responses = find_request_in_jtl(jtl_content, refname)
        for response in jtl_responses:
            dynamic_values = find_dynamic_values_in_jtl(response, regex)
            logging.debug(f"Dynamic values found for {refname}: {dynamic_values}")

            for dynamic_value_set in dynamic_values:
                if int(match_number) <= len(dynamic_value_set):
                    extracted_value = dynamic_value_set[int(match_number) - 1]
                    logging.info(f"Extracted value using template {template}: {extracted_value}")
                else:
                    logging.warning(f"Match number {match_number} is out of range for extracted values")

        return True
    except Exception as e:
        logging.error(f"Error validating and applying RegexExtractor: {e}")
        return False

def save_dynamic_values_to_file(file_path, dynamic_values):
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            for var_name, details in dynamic_values.items():
                f.write(f"Variable Name: {var_name}\n")
                f.write(f"Regular Expression: {details['regex']}\n")
                f.write(f"Template: {details['template']}\n")
                f.write(f"Match Number: {details['match_number']}\n")
                f.write("Dynamic Values:\n")
                for value_set in details['values']:
                    f.write(f"  {' | '.join(value_set)}\n")
                f.write("\n")
        logging.info(f"Dynamic values saved to {file_path}")
    except Exception as e:
        logging.error(f"Error saving dynamic values to file {file_path}: {e}")
        raise

def copy_regex_extractors(base_root, new_root, jtl_content):
    dynamic_values_dict = {}  # Dictionary to store dynamic values and details

    base_requests = find_http_samplers(base_root)
    logging.debug(f"Found {len(base_requests)} HTTP Samplers in base script")
    
    for base_request in base_requests:
        request_name = base_request.get("testname")
        logging.debug(f"Processing request: {request_name}")
        
        matching_new_request = find_request_by_name(new_root, request_name)
        if matching_new_request:
            logging.debug(f"Found matching request in new script: {request_name}")
            elements = find_elements_in_request_subtree(base_request)
            logging.debug(f"Found {len(elements)} elements in base request's subtree")
            
            matching_new_hash_tree = matching_new_request[0].getnext()
            if matching_new_hash_tree is not None and matching_new_hash_tree.tag == "hashTree":
                for element in elements:
                    if element.tag == "RegexExtractor":
                        if validate_and_apply_extractor(element, jtl_content):
                            copied_element = copy.deepcopy(element)
                            matching_new_hash_tree.append(copied_element)
                            new_hash_tree = etree.Element("hashTree")
                            matching_new_hash_tree.append(new_hash_tree)
                            logging.debug(f"Copied and validated RegexExtractor for request: {request_name}")
                            
                            regex = copied_element.find(".//stringProp[@name='RegexExtractor.regex']").text
                            template = copied_element.find(".//stringProp[@name='RegexExtractor.template']").text
                            match_number = copied_element.find(".//stringProp[@name='RegexExtractor.match_number']").text
                            regex_variable_name = copied_element.find(".//stringProp[@name='RegexExtractor.refname']").text
                            if regex:
                                logging.debug(f"Regex for request {request_name}: {regex}")
                                
                                jtl_responses = find_request_in_jtl(jtl_content, request_name)
                                if jtl_responses:
                                    logging.debug(f"Found {len(jtl_responses)} matching responses for request {request_name}")
                                    for jtl_response in jtl_responses:
                                        dynamic_values = find_dynamic_values_in_jtl(jtl_response, regex)
                                        logging.debug(f"Dynamic values found: {dynamic_values}")
                                        
                                        if regex_variable_name:
                                            logging.debug(f"Replacing dynamic values with variable name: {regex_variable_name}")
                                            matching_new_request[0] = replace_dynamic_values_in_jmx(matching_new_request[0], dynamic_values, regex_variable_name)
                                            
                                            # Add to dictionary with additional details
                                            if regex_variable_name not in dynamic_values_dict:
                                                dynamic_values_dict[regex_variable_name] = {
                                                    'regex': regex,
                                                    'template': template,
                                                    'match_number': match_number,
                                                    'values': []
                                                }
                                            dynamic_values_dict[regex_variable_name]['values'].extend(dynamic_values)
                                else:
                                    logging.debug(f"No matching JTL response found for request {request_name}")
                            else:
                                logging.debug(f"Regex is missing or empty for request {request_name}, skipping.")
                    else:
                        continue
        else:
            logging.debug(f"No matching request found in new script for: {request_name}")

    return dynamic_values_dict

def save_jmx(tree, file_path):
    try:
        tree.write(file_path, pretty_print=True, xml_declaration=True, encoding="UTF-8")
    except Exception as e:
        logging.error(f"Error saving JMX file {file_path}: {e}")
        raise

def main(base_jmx, new_jmx, output_jmx, jtl_file, dynamic_values_file):
    try:
        # Sanitize JMX files before parsing to remove invalid XML characters
        base_jmx_sanitized = sanitize_xml(base_jmx)
        new_jmx_sanitized = sanitize_xml(new_jmx)

        base_tree, base_root = parse_jmx(base_jmx_sanitized)
        new_tree, new_root = parse_jmx(new_jmx_sanitized)
        jtl_content = parse_jtl(jtl_file)

        dynamic_values = copy_regex_extractors(base_root, new_root, jtl_content)
        save_dynamic_values_to_file(dynamic_values_file, dynamic_values)
        save_jmx(new_tree, output_jmx)

        logging.info("Processing complete.")
    except Exception as e:
        logging.error(f"An error occurred: {e}")

# Example usage
if __name__ == "__main__":
    main(
        base_jmx="C:/Users/Sreenu Gali/Desktop/AutoCorrelations/Experiment/Compare_Replace/BTF_MasterScript_ALL.jmx",
        new_jmx="C:/Users/Sreenu Gali/Desktop/AutoCorrelations/Experiment/Compare_Replace/TC11_LOB_Creating_a_Remittance_Report.jmx",
        output_jmx="C:/Users/Sreenu Gali/Desktop/AutoCorrelations/Experiment/Compare_Replace/Output_Script.jmx",
        jtl_file="C:/Users/Sreenu Gali/Desktop/AutoCorrelations/Experiment/Compare_Replace/TC11_LOB_Creating a Remittance Report.jtl",
        dynamic_values_file="C:/Users/Sreenu Gali/Desktop/AutoCorrelations/Experiment/Compare_Replace/dynamic_values.txt"
    )
