from lxml import etree
import copy

# Function to parse the JMX file
def parse_jmx(file_path):
    tree = etree.parse(file_path)
    root = tree.getroot()
    return tree, root

# Function to find all HTTP Samplers (requests) in the JMX file
def find_http_samplers(root):
    return root.xpath(".//HTTPSamplerProxy")

# Function to find Regular Expression Extractors under a given request
def find_regex_extractors(request):
    return request.xpath(".//RegexExtractor")

# Function to find a request by its name (or testname attribute)
def find_request_by_name(root, request_name):
    return root.xpath(f".//HTTPSamplerProxy[@testname='{request_name}']")

# Function to copy Regular Expression Extractors from base to new script
def copy_extractors(base_root, new_root):
    base_requests = find_http_samplers(base_root)
    for base_request in base_requests:
        request_name = base_request.get("testname")
        matching_new_request = find_request_by_name(new_root, request_name)
        if matching_new_request:
            extractors = find_regex_extractors(base_request)
            for extractor in extractors:
                # Deep copy the extractor and append it to the new request
                copied_extractor = copy.deepcopy(extractor)
                matching_new_request[0].append(copied_extractor)
                print(f"Copied extractor for request: {request_name}")

# Function to save the modified JMX file
def save_jmx(tree, file_path):
    tree.write(file_path, pretty_print=True, xml_declaration=True, encoding="UTF-8")

# Main function
def main(base_jmx, new_jmx, output_jmx):
    # Parse both base and new JMX files
    base_tree, base_root = parse_jmx(base_jmx)
    new_tree, new_root = parse_jmx(new_jmx)
    
    # Copy extractors from base to new script
    copy_extractors(base_root, new_root)
    
    # Save the modified new script to an output file
    save_jmx(new_tree, output_jmx)
    print(f"Modified JMX saved as {output_jmx}")

if __name__ == "__main__":
    base_jmx_path = "C:/Users/Sreenu Gali/Desktop/AutoCorrelations/Experiment/PythonCompare/Base_Script.jmx"  # Path to your base script
    new_jmx_path = "C:/Users/Sreenu Gali/Desktop/AutoCorrelations/Experiment/PythonCompare/New_Script.jmx"    # Path to your newly recorded script
    output_jmx_path = "C:/Users/Sreenu Gali/Desktop/AutoCorrelations/Experiment/PythonCompare/output_script.jmx"  # Path to save the modified script
    
    main(base_jmx_path, new_jmx_path, output_jmx_path)
